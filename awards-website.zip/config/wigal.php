<?php
/**
 * Wigal API Configuration
 */

define('WIGAL_API_KEY', 'YOUR_WIGAL_API_KEY');
define('WIGAL_APP_ID', 'YOUR_WIGAL_APP_ID');
define('WIGAL_SENDER_ID', 'VOTEHUBGH'); // For SMS
define('WIGAL_PAYMENT_URL', 'https://api.wigal.com.gh/v1/payment'); // Example URL
define('WIGAL_SMS_URL', 'https://api.wigal.com.gh/v1/sms'); // Example URL

// USSD Settings
define('USSD_VOTE_PRICE', 1.00); // Default price per vote if not set in event
define('USSD_CURRENCY', 'GHS');
