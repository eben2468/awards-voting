<?php
/**
 * Paystack Configuration
 */

// Paystack API Keys (Replace with actual keys in production)
define('PAYSTACK_PUBLIC_KEY', 'pk_live_e95a818b54569bbe76db3a2383493d0d71d9ba38');
define('PAYSTACK_SECRET_KEY', 'sk_live_4adada6eac9f0bb198bd02417000b4e48d60a6c5');

// Payment Settings
define('CURRENCY', 'GHS');
define('VOTE_PRICE', 1.00); // Default price per vote if not set in event

/**
 * Initialize Paystack Transaction
 */
function initializePaystack($email, $amount, $reference, $metadata = []) {
    $url = "https://api.paystack.co/transaction/initialize";
    
    $fields = [
        'email' => $email,
        'amount' => $amount * 100, // Paystack expects amount in pesewas/kobo
        'currency' => CURRENCY,
        'reference' => $reference,
        'metadata' => $metadata,
        'callback_url' => SITE_URL . '/verify-payment.php'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
        "Cache-Control: no-cache",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);

    return json_decode($result, true);
}

/**
 * Verify Paystack Transaction
 */
function verifyPaystack($reference) {
    $url = "https://api.paystack.co/transaction/verify/" . rawurlencode($reference);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
        "Cache-Control: no-cache",
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);

    return json_decode($result, true);
}
