<?php
/**
 * USSD Endpoint for Frog Wigal Smart USSD API (V1)
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/wigal.php';

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    echo json_encode(['message' => 'Invalid Request', 'type' => 'release']);
    exit;
}

$msisdn = $data['msisdn'] ?? '';
$sessionId = $data['sessionid'] ?? '';
$userData = trim($data['userdata'] ?? '');
$network = $data['network'] ?? '';

$db = getDBConnection();

// Check if session exists
$stmt = $db->prepare("SELECT * FROM ussd_sessions WHERE session_id = ?");
$stmt->execute([$sessionId]);
$session = $stmt->fetch();

if (!$session) {
    // New Session - Step 1: Welcome & Enter Nominee Code
    $stmt = $db->prepare("INSERT INTO ussd_sessions (session_id, msisdn, current_step) VALUES (?, ?, 1)");
    $stmt->execute([$sessionId, $msisdn]);
    
    $response = [
        'message' => "Welcome to " . SITE_NAME . " Voting\nEnter Nominee Code:",
        'type' => 'continue'
    ];
} else {
    $currentStep = $session['current_step'];
    
    switch ($currentStep) {
        case 1:
            // User entered Nominee Code - Step 2: Enter Quantity
            $stmt = $db->prepare("SELECT n.*, e.vote_price, e.title as event_title 
                                 FROM nominees n 
                                 JOIN categories c ON n.category_id = c.id 
                                 JOIN events e ON c.event_id = e.id 
                                 WHERE n.shortcode = ? AND n.status = 'active' AND e.status = 'active'");
            $stmt->execute([$userData]);
            $nominee = $stmt->fetch();
            
            if ($nominee) {
                // Update session
                $stmt = $db->prepare("UPDATE ussd_sessions SET current_step = 2, nominee_id = ? WHERE session_id = ?");
                $stmt->execute([$nominee['id'], $sessionId]);
                
                $response = [
                    'message' => "Vote for " . $nominee['name'] . " (" . $nominee['event_title'] . ")\nEnter number of votes:",
                    'type' => 'continue'
                ];
            } else {
                $response = [
                    'message' => "Invalid Nominee Code. Please try again:",
                    'type' => 'continue'
                ];
            }
            break;
            
        case 2:
            // User entered Quantity - Step 3: Confirm Vote
            $quantity = intval($userData);
            if ($quantity > 0) {
                // Get nominee and price
                $stmt = $db->prepare("SELECT n.*, e.vote_price, e.title as event_title 
                                     FROM nominees n 
                                     JOIN categories c ON n.category_id = c.id 
                                     JOIN events e ON c.event_id = e.id 
                                     WHERE n.id = ?");
                $stmt->execute([$session['nominee_id']]);
                $nominee = $stmt->fetch();
                
                if ($nominee) {
                    $unitPrice = $nominee['vote_price'] > 0 ? $nominee['vote_price'] : USSD_VOTE_PRICE;
                    $totalPrice = $unitPrice * $quantity;
                    
                    // Update session
                    $stmt = $db->prepare("UPDATE ussd_sessions SET current_step = 3, vote_count = ? WHERE session_id = ?");
                    $stmt->execute([$quantity, $sessionId]);
                    
                    $response = [
                        'message' => "Confirm Vote for " . $nominee['name'] . "\nQty: " . $quantity . "\nTotal: " . USSD_CURRENCY . " " . number_format($totalPrice, 2) . "\n1. Confirm\n2. Cancel",
                        'type' => 'continue'
                    ];
                } else {
                    $response = [
                        'message' => "Nominee not found. Please start again.",
                        'type' => 'release'
                    ];
                    $stmt = $db->prepare("DELETE FROM ussd_sessions WHERE session_id = ?");
                    $stmt->execute([$sessionId]);
                }
            } else {
                $response = [
                    'message' => "Invalid quantity. Please enter a number:",
                    'type' => 'continue'
                ];
            }
            break;

        case 3:
            // User confirmed vote - Trigger Payment
            if ($userData == '1') {
                // Get nominee and price again
                $stmt = $db->prepare("SELECT n.*, e.vote_price, e.id as event_id, n.category_id 
                                     FROM nominees n 
                                     JOIN categories c ON n.category_id = c.id 
                                     JOIN events e ON c.event_id = e.id 
                                     WHERE n.id = ?");
                $stmt->execute([$session['nominee_id']]);
                $nominee = $stmt->fetch();
                
                $unitPrice = $nominee['vote_price'] > 0 ? $nominee['vote_price'] : USSD_VOTE_PRICE;
                $quantity = $session['vote_count'];
                $totalPrice = $unitPrice * $quantity;
                $reference = 'USSD-' . time() . '-' . rand(1000, 9999);
                
                // Create pending transaction
                $stmt = $db->prepare("INSERT INTO transactions (event_id, nominee_id, category_id, amount, quantity, reference, payment_method, provider, status, metadata) 
                                     VALUES (?, ?, ?, ?, ?, ?, 'ussd', ?, 'pending', ?)");
                $stmt->execute([
                    $nominee['event_id'],
                    $nominee['id'],
                    $nominee['category_id'],
                    $totalPrice,
                    $quantity,
                    $reference,
                    $network,
                    json_encode(['msisdn' => $msisdn, 'session_id' => $sessionId, 'quantity' => $quantity])
                ]);
                
                // Trigger Wigal Payment API (Mocking the call)
                // In a real scenario, you would use curl to call Wigal's payment endpoint
                /*
                $paymentPayload = [
                    'amount' => $totalPrice,
                    'customer_number' => $msisdn,
                    'reference' => $reference,
                    'callback_url' => SITE_URL . '/ussd/callback.php'
                ];
                // curl_exec...
                */
                
                $response = [
                    'message' => "Payment request of " . USSD_CURRENCY . " " . number_format($totalPrice, 2) . " sent to " . $msisdn . ". Please approve to complete your vote. Thank you!",
                    'type' => 'release'
                ];
                
                // Clean up session
                $stmt = $db->prepare("DELETE FROM ussd_sessions WHERE session_id = ?");
                $stmt->execute([$sessionId]);
                
            } else {
                $response = [
                    'message' => "Vote cancelled. Thank you for using " . SITE_NAME . ".",
                    'type' => 'release'
                ];
                // Clean up session
                $stmt = $db->prepare("DELETE FROM ussd_sessions WHERE session_id = ?");
                $stmt->execute([$sessionId]);
            }
            break;
            
        default:
            $response = [
                'message' => "An error occurred. Please try again.",
                'type' => 'release'
            ];
            $stmt = $db->prepare("DELETE FROM ussd_sessions WHERE session_id = ?");
            $stmt->execute([$sessionId]);
            break;
    }
}

echo json_encode($response);
