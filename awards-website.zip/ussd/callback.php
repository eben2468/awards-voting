<?php
/**
 * Payment Callback for Wigal
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/wigal.php';

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    http_response_code(400);
    exit('Invalid Request');
}

$status = $data['status'] ?? '';
$reference = $data['reference'] ?? '';
$amount = $data['amount'] ?? 0;
$msisdn = $data['msisdn'] ?? '';

$db = getDBConnection();

// Find the transaction
$stmt = $db->prepare("SELECT * FROM transactions WHERE reference = ? AND status = 'pending'");
$stmt->execute([$reference]);
$transaction = $stmt->fetch();

if (!$transaction) {
    http_response_code(404);
    exit('Transaction not found or already processed');
}

if ($status === 'SUCCESS') {
    try {
        $db->beginTransaction();

        // 1. Update Transaction
        $stmt = $db->prepare("UPDATE transactions SET status = 'success', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$transaction['id']]);

        $quantity = $transaction['quantity'] ?? 1;

        // 2. Record Vote
        $stmt = $db->prepare("INSERT INTO votes (nominee_id, category_id, event_id, transaction_id, vote_count, ip_address, user_agent) 
                             SELECT n.id, n.category_id, c.event_id, ?, ?, 'USSD', 'Wigal USSD'
                             FROM nominees n
                             JOIN categories c ON n.category_id = c.id
                             WHERE n.id = ?");
        $stmt->execute([$transaction['id'], $quantity, $transaction['nominee_id']]);

        // 3. Update Nominee Vote Count
        $stmt = $db->prepare("UPDATE nominees SET vote_count = vote_count + ? WHERE id = ?");
        $stmt->execute([$quantity, $transaction['nominee_id']]);

        // 4. Update Event Total Votes
        $stmt = $db->prepare("UPDATE events SET total_votes = total_votes + ? WHERE id = ?");
        $stmt->execute([$quantity, $transaction['event_id']]);

        $db->commit();

        // 5. Send Confirmation SMS (Mocking)
        $nomineeStmt = $db->prepare("SELECT name FROM nominees WHERE id = ?");
        $nomineeStmt->execute([$transaction['nominee_id']]);
        $nominee = $nomineeStmt->fetch();
        
        $smsMessage = "Thank you! Your vote for " . $nominee['name'] . " has been recorded successfully. Reference: " . $reference;
        // sendSMS($msisdn, $smsMessage);

        // 6. Create Notifications
        $eventStmt = $db->prepare("SELECT created_by, title FROM events WHERE id = ?");
        $eventStmt->execute([$transaction['event_id']]);
        $event = $eventStmt->fetch();
        
        if ($event) {
            // Notify Organizer
            if ($event['created_by']) {
                createNotification(
                    $event['created_by'],
                    "New Vote Recorded",
                    "A new vote has been cast for " . $nominee['name'] . " in your event: " . $event['title'],
                    "success",
                    "organizer/event-details.php?id=" . $transaction['event_id']
                );
            }
            
            // Notify Admin
            createNotification(
                1, // Admin ID
                "New Vote Recorded",
                "A new vote has been cast for " . $nominee['name'] . " in " . $event['title'],
                "info",
                "admin/votes.php"
            );
        }

        echo json_encode(['status' => 'success', 'message' => 'Vote recorded']);

    } catch (Exception $e) {
        $db->rollBack();
        http_response_code(500);
        exit('Error processing vote: ' . $e->getMessage());
    }
} else {
    // Update transaction as failed
    $stmt = $db->prepare("UPDATE transactions SET status = 'failed', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->execute([$transaction['id']]);
    
    echo json_encode(['status' => 'failed', 'message' => 'Payment failed']);
}

/**
 * Mock function to send SMS via Wigal
 */
function sendSMS($to, $message) {
    // In a real scenario, use curl to call WIGAL_SMS_URL
    return true;
}
